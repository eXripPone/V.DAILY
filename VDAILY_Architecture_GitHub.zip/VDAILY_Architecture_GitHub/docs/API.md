# Контракты HTTP API

JSON, UTF-8. Закрытые методы требуют `Authorization: Bearer <session_token>`. В live-режиме запрос проходит через локальный HTTPS-прокси. Идентификатор владельца сервер извлекает из сеанса, а не из тела запроса.

| Метод | Маршрут | Вход / результат |
|---|---|---|
| GET | /health | Состояние процесса и доступности БД |
| GET | /api/config | Режим demo/live |
| POST | /api/session | init_data с подписью Telegram, затем token |
| POST | /api/demo-session | Только localhost и явный demo-режим |
| GET / POST | /api/profile | Часовой пояс IANA и локальная дата |
| POST | /api/parse | text до 1000 символов, затем draft с ID и revision |
| GET | /api/records?view=today | Записи, today, timezone, drafts |
| GET | /api/records?view=calendar&day=YYYY-MM-DD | События выбранной даты |
| GET | /api/records?view=finance | Расходы владельца |
| GET | /api/records?view=history | История пяти типов записей |
| GET | /api/drafts/{id} | Черновик владельца |
| POST | /api/drafts/{id}/edit | revision, index, patch |
| POST | /api/drafts/{id}/confirm | revision, затем ID сохранённых записей |
| POST | /api/drafts/{id}/cancel | revision, затем cancelled=true |

Ошибки: 400 для ввода/разбора, 401 для авторизации, 404 для отсутствующего или чужого набора, 409 для устаревшей версии, 429 для ограничения запросов, 503 для сбоя операции. Поле error содержит сообщение для пользователя без ответа провайдера и личных данных.
