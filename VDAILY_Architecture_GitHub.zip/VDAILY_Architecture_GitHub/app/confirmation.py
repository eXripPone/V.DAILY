"""
Экран подтверждения.

Каждый набор сохраняется только после явного подтверждения, как требует
итоговый SRS. Любую запись можно исправить независимо от confidence.
"""

from __future__ import annotations

from app.models import EventRecord, ExpenseRecord, MealRecord, NoteRecord, Record, TaskRecord

CONFIDENCE_THRESHOLD = 0.75

# Сохранено для совместимости; текущая политика требует подтверждать все типы.
ALWAYS_CONFIRM_TYPES = (EventRecord.type, ExpenseRecord.type)

_ICON = {
    EventRecord.type: "📅",
    TaskRecord.type: "✅",
    ExpenseRecord.type: "💳",
    MealRecord.type: "🍲",
    NoteRecord.type: "📝",
}

_TAG = {
    EventRecord.type: "Календарь",
    TaskRecord.type: "Задачи",
    ExpenseRecord.type: "Финансы",
    MealRecord.type: "Питание",
    NoteRecord.type: "Дневник",
}


def needs_confirmation(record: Record) -> bool:
    """True, если запись нужно показать пользователю перед сохранением."""
    return True


def describe(record: Record) -> tuple[str, str]:
    """Возвращает (заголовок, подзаголовок) для одной записи — без иконки и тега."""
    match record:
        case EventRecord():
            when = " ".join(p for p in (record.date, record.time) if p) or "дата не распознана"
            title = record.title
            # Сравниваем по первым буквам, а не по точному вхождению: из-за
            # падежей "Андрей" не является подстрокой "Андреем", хотя это
            # одно и то же имя — простое вхождение здесь даёт ложные срабатывания.
            stem = record.with_person[:4].lower() if record.with_person else None
            if stem and stem not in title.lower():
                title = f"{title} ({record.with_person})"
            return title, when
        case TaskRecord():
            sub = f"до {record.due_date}" if record.due_date else "без срока"
            if record.priority != "normal":
                sub += f" · приоритет: {record.priority}"
            return record.title, sub
        case ExpenseRecord():
            return (f'{record.amount:g} {record.currency}' if record.amount is not None else 'Уточните сумму'), f"категория «{record.category}»"
        case MealRecord():
            sub = f"≈{record.calories_kcal} ккал · Б {record.protein_g} / Ж {record.fat_g} / У {record.carbs_g} г · порция ≈{record.portion_g} г" if record.calories_kcal is not None else "Уточните КБЖУ и массу порции"
            return record.description, sub
        case NoteRecord():
            return record.text, "заметка"
        case _:  # pragma: no cover - защита на случай нового типа без describe()
            return record.raw_phrase or "запись", record.type


def format_confirmation_card(records: list[Record]) -> str:
    """
    Собирает текст карточки подтверждения — ровно то, что показано в примере
    на главном экране One Pager: «Встреча с Андреем / завтра, 15:00 / Календарь» и т.д.
    """
    if not records:
        return "Не нашёл в сообщении ничего, что можно разложить по разделам."

    lines = ["Разложил сообщение по разделам:", ""]
    for record in records:
        title, subtitle = describe(record)
        icon = _ICON.get(record.type, "•")
        tag = _TAG.get(record.type, record.type)
        marker = " · нужно подтвердить" if needs_confirmation(record) else ""
        lines.append(f"{icon} {title}{marker}")
        lines.append(f"   {subtitle} — {tag}")
    return "\n".join(lines)


def build_inline_keyboard(records: list[Record], batch_id: str = 'preview', revision: int = 0) -> list[list[tuple[str, str]]]:
    """
    Описывает кнопки подтверждения в виде независимой от aiogram структуры:
    список строк, строка — список (текст, callback_data). bot.py превращает
    это в настоящую aiogram.InlineKeyboardMarkup.
    """
    rows: list[list[tuple[str, str]]] = []

    flagged = [i for i, r in enumerate(records) if needs_confirmation(r)]
    for i in flagged:
        title, _ = describe(records[i])
        short = title if len(title) <= 24 else title[:21] + "…"
        rows.append([(f"✏️ Исправить «{short}»", f"edit:{batch_id}:{revision}:{i}")])

    if records:
        rows.append([("✅ Всё верно, сохранить", f"confirm:{batch_id}:{revision}"),('Отменить',f'cancel:{batch_id}:{revision}')])
    return rows
