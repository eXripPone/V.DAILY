"""Application use cases shared by Telegram, HTTP and acceptance tests."""
import json
import re
from datetime import date,timedelta
from app.llm_parser import ParsingError,parse_voice_text
from app.models import ValidationError,parse_records,missing_fields

class DemoClient:
    """Explicit offline rule parser; never presented as a measured LLM result."""
    def complete(self,system,user):
        today=date.fromisoformat(re.search(r'сегодняшнюю дату: (\d{4}-\d{2}-\d{2})',system)[1])
        text=user.split('\n',1)[1]; records=[]
        parts=re.split(r'[,;\n]+(?!\s*напомни)',text)
        for part in parts:
            s=part.strip(); low=s.lower()
            if not s: continue
            day=today+timedelta(days=2 if 'послезавтра' in low else 1 if 'завтра' in low else -1 if 'вчера' in low else 0)
            explicit=re.search(r'\d{4}-\d{2}-\d{2}',s)
            if explicit: day=date.fromisoformat(explicit[0])
            if any(w in low for w in ('встреч','созвон','событие','совещание')):
                t=re.search(r'\b([01]?\d|2[0-3]):([0-5]\d)\b',s)
                time=f'{int(t[1]):02d}:{t[2]}' if t else None
                dated=explicit is not None or any(w in low for w in ('завтра','сегодня','вчера'))
                reminder=re.search(r'напомни за (\d+)\s*(мин|час)',low)
                minutes=int(reminder[1])*(60 if reminder[2]=='час' else 1) if reminder else 60 if 'напомни за час' in low else None
                title=re.sub(r'(послезавтра|завтра|сегодня|\d{4}-\d{2}-\d{2})|\bв\s+\d{1,2}:\d{2}|,?\s*напомни.*','',s,flags=re.I).strip(' ,')
                records.append({'type':'event','title':title or 'Встреча','date':day.isoformat() if dated else None,'time':time,'needs_time_clarification':not time and bool(re.search(r'\bв\s+(три|два|четыре|пять|\d{1,2})\b',low)),'reminder_minutes':minutes})
            elif any(w in low for w in ('потратил','заплатил','расход','купил')):
                m=re.search(r'\d+(?:[.,]\d+)?',s)
                category='Транспорт' if any(w in low for w in ('такси','метро','автобус')) else 'Питание' if any(w in low for w in ('обед','еда','продукт')) else 'Прочее'
                records.append({'type':'expense','amount':float(m[0].replace(',','.')) if m else None,'category':category,'description':s,'occurred_on':day.isoformat()})
            elif any(w in low for w in ('на обед','на ужин','на завтрак','съел','борщ','питание:')):
                records.append({'type':'meal','description':s,'occurred_on':day.isoformat()})
            elif any(w in low for w in ('не забыть','задача:','надо','нужно','купить','оплатить')):
                title=re.sub(r'^(не забыть|задача:|надо|нужно)\s*','',s,flags=re.I)
                due=day.isoformat() if any(w in low for w in ('завтра','сегодня')) or explicit else None
                records.append({'type':'task','title':title[:1].upper()+title[1:],'due_date':due})
            else: records.append({'type':'note','text':re.sub(r'^заметка:\s*','',s,flags=re.I),'occurred_on':day.isoformat()})
        return json.dumps(records,ensure_ascii=False)

def enrich_meal(item):
    # Small explicit reference catalog per 100g for offline demonstrations.
    # Live estimates from the provider are retained only when complete.
    nutrients=('calories_kcal','protein_g','fat_g','carbs_g')
    if all(item.get(k) is not None for k in (*nutrients,'portion_g')): return item
    catalog={'борщ':(49,3,2,5),'овсян':(88,3,2,15),'рис':(130,2.7,.3,28),'греч':(110,4,1,21)}
    for word,values in catalog.items():
        if word in item.get('description','').lower():
            m=re.search(r'(\d+)\s*г\b',item['description'])
            portion=float(m[1]) if m else 300.0
            item.update({k:round(v*portion/100,1) for k,v in zip(nutrients,values)})
            item.update(portion_g=portion,estimated=True)
            break
    return item

class Service:
    def __init__(self,storage,client): self.storage=storage; self.client=client

    def propose(self,user,text):
        if not isinstance(text,str) or not text.strip(): raise ValidationError('Введите сообщение')
        if len(text)>1000: raise ValidationError('Лимит — 1000 символов, включая пробелы')
        self.storage.ensure_user(user)
        if not self.storage.user_zone(user): raise ValidationError('Сначала выберите часовой пояс')
        records=parse_voice_text(text,self.client,self.storage.today(user))
        data=[]
        for r in records:
            item=r.to_dict()
            if item['type']=='meal': item=enrich_meal(item)
            if item['type']=='event' and re.search(r'\bв\s+(три|два|четыре|пять|шесть|семь|восемь|девять|десять|одиннадцать|двенадцать)\b',text.lower()) and not re.search(r'утра|вечера|дня|ночи',text.lower()):
                item.update(time=None,needs_time_clarification=True)
            if item['type'] not in ('event','task') and not item.get('occurred_on'): item['occurred_on']=self.storage.today(user).isoformat()
            data.append(item)
        if not data: raise ValidationError('Не нашёл записей. Опишите встречу, дело, расход, еду или заметку.')
        return self.storage.new_draft(user,parse_records(data))

    def edit(self,user,batch,index,patch,revision):
        if not isinstance(patch,dict) or not patch: raise ValidationError('Укажите изменяемые поля')
        return self.storage.edit_draft(user,batch,index,patch,revision)

    def feed(self,user,view='today',day=None):
        if day:
            try: date.fromisoformat(day)
            except (ValueError,TypeError): raise ValidationError('Дата: YYYY-MM-DD')
        today=self.storage.today(user).isoformat()
        if view=='today': rows=self.storage.list_records(user,day=today)
        elif view=='calendar': rows=self.storage.list_records(user,'event',day or today)
        elif view=='finance': rows=self.storage.list_records(user,'expense')
        elif view=='history': rows=self.storage.list_records(user)
        else: raise ValidationError('Неизвестный экран')
        return {'records':rows,'today':today,'timezone':self.storage.user_zone(user),'drafts':self.storage.pending(user)}

def draft_public(draft):
    result=dict(draft)
    result['missing']=[missing_fields(r) for r in parse_records(draft['records'])]
    return result
