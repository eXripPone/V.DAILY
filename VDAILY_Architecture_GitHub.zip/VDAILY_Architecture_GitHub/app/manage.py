"""Local-only administration; never exposed to Mini App users."""
import argparse,csv,json
from app.storage import Storage

def main():
    p=argparse.ArgumentParser(); p.add_argument('action',choices=['metrics','review']); p.add_argument('--db',default='vdaily.sqlite3'); p.add_argument('--csv'); args=p.parse_args()
    db=Storage(args.db)
    try:
        if args.action=='review':
            if not args.csv: p.error('Для review нужен --csv с колонками record_id,major_error')
            with open(args.csv,encoding='utf-8-sig',newline='') as file: rows=list(csv.DictReader(file))
            with db.transaction():
                for row in rows:
                    record_id=int(row['record_id']); value=int(row['major_error'])
                    if value not in (0,1): raise ValueError('major_error: только 0 или 1')
                    if not db._conn.execute('SELECT 1 FROM records WHERE id=?',(record_id,)).fetchone(): raise ValueError('Нет записи с указанным record_id')
                    db._conn.execute('INSERT OR REPLACE INTO reviews VALUES(?,?)',(record_id,value))
            print('Разметка импортирована:',len(rows))
        print(json.dumps(db.metrics(),ensure_ascii=False,indent=2))
    finally: db.close()

if __name__=='__main__': main()
