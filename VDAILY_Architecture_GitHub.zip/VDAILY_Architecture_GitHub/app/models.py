"""
Модели записей V.DAILY.

Любое голосовое сообщение разбирается LLM на набор разнотипных записей:
событие, задача, расход, приём пищи или заметка (если ничего из перечисленного
не подошло). Здесь — только данные и их валидация, без обращения к сети и без
знания о Telegram или LLM: это чистый, легко тестируемый слой.
"""

from __future__ import annotations

import re
import math
from datetime import date as calendar_date
from dataclasses import dataclass, field, asdict
from typing import Any, ClassVar, Literal

# ---------------------------------------------------------------------------
# Ошибки
# ---------------------------------------------------------------------------


class ValidationError(ValueError):
    """Запись пришла от LLM в некорректном виде — не доверяем ей молча."""


# ---------------------------------------------------------------------------
# Базовый класс записи
# ---------------------------------------------------------------------------

_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_TIME_RE = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")


def _check_date(value: str | None, field_name: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or not _DATE_RE.match(value):
        raise ValidationError(f"{field_name} должен быть в формате YYYY-MM-DD, получено: {value!r}")
    try:
        calendar_date.fromisoformat(value)
    except ValueError as exc:
        raise ValidationError(f'{field_name}: такой даты не существует') from exc
    return value


def _check_time(value: str | None, field_name: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or not _TIME_RE.match(value):
        raise ValidationError(f"{field_name} должен быть в формате HH:MM, получено: {value!r}")
    return value


def _require_text(value: Any, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValidationError(f"{field_name} обязателен и не может быть пустым")
    if len(value)>1000: raise ValidationError(f'{field_name}: не более 1000 символов')
    return value.strip()


@dataclass
class Record:
    """Общие поля для всех типов записей."""

    type: ClassVar[str] = "record"

    raw_phrase: str = ""
    # Насколько LLM уверена в разборе именно этого фрагмента (0..1).
    # Используется слоем confirmation.py, чтобы решить, нужно ли спрашивать
    # пользователя, а не превращать каждую запись в обязательное подтверждение.
    confidence: float = 1.0
    occurred_on: str | None = None

    def __post_init__(self) -> None:
        if type(self.confidence) not in (int, float) or not math.isfinite(self.confidence) or not (0.0 <= self.confidence <= 1.0):
            raise ValidationError(f"confidence должен быть в диапазоне 0..1, получено: {self.confidence}")
        self.occurred_on = _check_date(self.occurred_on, 'occurred_on')
        if not isinstance(self.raw_phrase, str) or len(self.raw_phrase)>1000:
            raise ValidationError('raw_phrase: ожидается строка до 1000 символов')

    def to_dict(self) -> dict:
        data = asdict(self)
        data["type"] = self.type
        return data


@dataclass
class EventRecord(Record):
    """Встреча/событие в календаре."""

    type: ClassVar[str] = "event"

    title: str = ""
    date: str | None = None          # YYYY-MM-DD, уже resolved из "завтра"/"в пятницу"
    time: str | None = None          # HH:MM
    with_person: str | None = None
    reminder_minutes: int | None = None
    needs_time_clarification: bool = False

    def __post_init__(self) -> None:
        super().__post_init__()
        self.title = _require_text(self.title, "title")
        self.date = _check_date(self.date, "date")
        self.time = _check_time(self.time, "time")
        if self.with_person is not None: self.with_person=_require_text(self.with_person,'with_person')
        if self.reminder_minutes is not None and (type(self.reminder_minutes) is not int or not 0 <= self.reminder_minutes <= 10080):
            raise ValidationError('Напоминание: от 0 до 10080 минут')


@dataclass
class TaskRecord(Record):
    """Дело / задача, необязательно с дедлайном."""

    type: ClassVar[str] = "task"

    title: str = ""
    due_date: str | None = None
    due_time: str | None = None
    priority: Literal["low", "normal", "high"] = "normal"

    def __post_init__(self) -> None:
        super().__post_init__()
        self.title = _require_text(self.title, "title")
        self.due_date = _check_date(self.due_date, "due_date")
        self.due_time = _check_time(self.due_time, 'due_time')
        if self.priority not in ("low", "normal", "high"):
            raise ValidationError(f"priority должен быть low/normal/high, получено: {self.priority!r}")


@dataclass
class ExpenseRecord(Record):
    """Трата с суммой и категорией."""

    type: ClassVar[str] = "expense"

    amount: float | None = None
    currency: str = "RUB"
    category: str = "Прочее"
    description: str = ''

    def __post_init__(self) -> None:
        super().__post_init__()
        if self.amount is not None and (type(self.amount) not in (int, float) or not math.isfinite(self.amount) or self.amount <= 0):
            raise ValidationError(f"amount должен быть положительным числом, получено: {self.amount!r}")
        self.category = _require_text(self.category, "category")
        if self.currency != 'RUB':
            raise ValidationError('В MVP поддерживаются только расходы в RUB')


@dataclass
class MealRecord(Record):
    """Приём пищи, КБЖУ — оценка, не точная цифра (см. ключевые риски проекта)."""

    type: ClassVar[str] = "meal"

    description: str = ""
    calories_kcal: int | None = None
    protein_g: float | None = None
    fat_g: float | None = None
    carbs_g: float | None = None
    portion_g: float | None = None
    estimated: bool = True

    def __post_init__(self) -> None:
        super().__post_init__()
        self.description = _require_text(self.description, "description")
        for name in ('calories_kcal','protein_g','fat_g','carbs_g','portion_g'):
            value=getattr(self,name)
            if value is not None and (type(value) not in (int,float) or not math.isfinite(value) or value<0 or (name=='portion_g' and value==0)):
                raise ValidationError(f'{name}: ожидается конечное неотрицательное число')


@dataclass
class NoteRecord(Record):
    """Всё, что не подошло ни под один другой тип — остаётся в дневнике."""

    type: ClassVar[str] = "note"

    text: str = ""

    def __post_init__(self) -> None:
        super().__post_init__()
        self.text = _require_text(self.text, "text")


# Реестр "type в JSON" -> класс. Расширять только здесь — остальной код
# (parser, storage, confirmation) новые типы подхватывает автоматически.
RECORD_CLASSES: dict[str, type[Record]] = {
    EventRecord.type: EventRecord,
    TaskRecord.type: TaskRecord,
    ExpenseRecord.type: ExpenseRecord,
    MealRecord.type: MealRecord,
    NoteRecord.type: NoteRecord,
}


def parse_records(raw_items: list[dict]) -> list[Record]:
    """
    Превращает список «сырых» dict (то, что вернула LLM после json.loads)
    в типизированные записи. Бросает ValidationError с понятным сообщением
    на первой же плохой записи — лучше не сохранить ничего, чем сохранить
    наполовину мусор.
    """
    if not isinstance(raw_items, list):
        raise ValidationError(f"Ожидался список записей, получено: {type(raw_items).__name__}")

    records: list[Record] = []
    for i, item in enumerate(raw_items):
        if not isinstance(item, dict):
            raise ValidationError(f"Запись #{i} должна быть объектом, получено: {type(item).__name__}")
        item = dict(item)  # не мутируем вход
        record_type = item.pop("type", None)
        cls = RECORD_CLASSES.get(record_type) if isinstance(record_type,str) else None
        if cls is None:
            known = ", ".join(sorted(RECORD_CLASSES))
            raise ValidationError(f"Запись #{i}: неизвестный type={record_type!r}, ожидается один из: {known}")
        try:
            records.append(cls(**item))
        except TypeError as exc:
            # лишнее/недостающее поле от LLM — тоже ValidationError, единая точка обработки
            raise ValidationError(f"Запись #{i} ({record_type}): некорректные поля — {exc}") from exc
    return records


def missing_fields(record: Record) -> list[str]:
    """Черновик может быть неполным; сохранённая запись — никогда."""
    missing=[]
    if isinstance(record, EventRecord):
        if not record.date: missing.append('date')
        if record.reminder_minutes is not None and not record.time: missing.append('time')
        if record.needs_time_clarification and not record.time and 'time' not in missing: missing.append('time')
    if isinstance(record, ExpenseRecord) and record.amount is None:
        missing.append('amount')
    if isinstance(record, MealRecord):
        missing.extend(name for name in ('calories_kcal','protein_g','fat_g','carbs_g','portion_g') if getattr(record,name) is None)
    return missing


def validate_ready(record: Record) -> None:
    # Repeat validation: dataclasses are mutable and untrusted edits must not bypass it.
    rebuilt=parse_records([record.to_dict()])[0]
    missing=missing_fields(rebuilt)
    if missing: raise ValidationError('Уточните поля: '+', '.join(missing))
