"""Durable SQLite drafts, atomic confirmation and text-free analytics."""
from __future__ import annotations
import json
import secrets
import sqlite3
import threading
from collections import defaultdict
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from app.models import EventRecord, TaskRecord, ValidationError, parse_records, validate_ready

def utcnow(): return datetime.now(timezone.utc)

def zone(name):
    try: return ZoneInfo(name)
    except ZoneInfoNotFoundError:
        if name in ('UTC','Etc/UTC'): return timezone.utc
        if name=='Europe/Moscow': return timezone(timedelta(hours=3),name)
        raise ValidationError('Неизвестный часовой пояс IANA. Установите tzdata.')

class Conflict(ValidationError): pass
class NotFound(ValidationError): pass

class Storage:
    def __init__(self,path=':memory:'):
        self._lock=threading.RLock()
        self._conn=sqlite3.connect(path,check_same_thread=False,isolation_level=None,timeout=10)
        self._conn.row_factory=sqlite3.Row
        self._conn.executescript('''
        PRAGMA foreign_keys=ON;
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,tz TEXT,first_seen TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS drafts(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,payload TEXT NOT NULL,original TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',revision INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS records(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,type TEXT NOT NULL,payload TEXT NOT NULL,created_at TEXT NOT NULL,day TEXT NOT NULL,batch_id TEXT,item_index INTEGER,UNIQUE(batch_id,item_index));
        CREATE INDEX IF NOT EXISTS records_user_day ON records(user_id,day);
        CREATE TABLE IF NOT EXISTS analytics(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL,event TEXT NOT NULL,batch_id TEXT,item_index INTEGER,at TEXT NOT NULL);
        CREATE UNIQUE INDEX IF NOT EXISTS analytics_once ON analytics(event,batch_id,item_index) WHERE event IN ('confirmed','saved','proposed');
        CREATE TABLE IF NOT EXISTS reminders(record_id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL,due_at TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',attempts INTEGER NOT NULL DEFAULT 0,claimed_at TEXT,last_attempt TEXT);
        CREATE TABLE IF NOT EXISTS dialogue(user_id INTEGER PRIMARY KEY,state TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS reviews(record_id INTEGER PRIMARY KEY,major_error INTEGER NOT NULL CHECK(major_error IN(0,1)));
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        ''')

    @contextmanager
    def transaction(self):
        with self._lock:
            self._conn.execute('BEGIN IMMEDIATE')
            try:
                yield
                self._conn.execute('COMMIT')
            except BaseException:
                self._conn.execute('ROLLBACK'); raise

    def close(self):
        with self._lock: self._conn.close()

    def _event(self,user,event,batch=None,index=None,at=None):
        self._conn.execute('INSERT OR IGNORE INTO analytics(user_id,event,batch_id,item_index,at) VALUES(?,?,?,?,?)',(user,event,batch,index,(at or utcnow()).isoformat()))

    def ensure_user(self,user):
        with self.transaction():
            cur=self._conn.execute('INSERT OR IGNORE INTO users VALUES(?,NULL,?)',(user,utcnow().isoformat()))
            if cur.rowcount: self._event(user,'first_contact')

    def user_zone(self,user):
        with self._lock:
            row=self._conn.execute('SELECT tz FROM users WHERE id=?',(user,)).fetchone()
            return row['tz'] if row else None

    def set_zone(self,user,name):
        zone(name); self.ensure_user(user)
        with self.transaction(): self._conn.execute('UPDATE users SET tz=? WHERE id=?',(name,user))

    def today(self,user,now=None):
        return (now or utcnow()).astimezone(zone(self.user_zone(user) or 'UTC')).date()

    def set_state(self,user,state):
        with self.transaction():
            if state is None: self._conn.execute('DELETE FROM dialogue WHERE user_id=?',(user,))
            else: self._conn.execute('INSERT OR REPLACE INTO dialogue VALUES(?,?)',(user,json.dumps(state)))

    def get_state(self,user):
        with self._lock:
            row=self._conn.execute('SELECT state FROM dialogue WHERE user_id=?',(user,)).fetchone()
            return json.loads(row[0]) if row else None

    def new_draft(self,user,records):
        self.ensure_user(user); batch=secrets.token_hex(6)
        data=[r.to_dict() for r in records]
        with self.transaction():
            payload=json.dumps(data,ensure_ascii=False,allow_nan=False)
            self._conn.execute('INSERT INTO drafts(id,user_id,payload,original,created_at) VALUES(?,?,?,?,?)',(batch,user,payload,payload,utcnow().isoformat()))
            for i in range(len(data)): self._event(user,'proposed',batch,i)
        return self.draft(user,batch)

    def draft(self,user,batch):
        with self._lock:
            row=self._conn.execute('SELECT * FROM drafts WHERE id=? AND user_id=?',(batch,user)).fetchone()
            if not row: raise NotFound('Набор не найден')
            result=dict(row); result['records']=json.loads(result.pop('payload')); result.pop('original')
            return result

    def pending(self,user):
        with self._lock:
            ids=self._conn.execute("SELECT id FROM drafts WHERE user_id=? AND status='pending' ORDER BY created_at DESC",(user,)).fetchall()
            return [self.draft(user,r[0]) for r in ids]

    def edit_draft(self,user,batch,index,patch,revision):
        with self.transaction():
            d=self.draft(user,batch)
            if d['status']!='pending' or d['revision']!=revision: raise Conflict('Карточка устарела. Откройте актуальный черновик.')
            if not 0<=index<len(d['records']): raise ValidationError('Нет такой записи')
            item=d['records'][index]
            if 'type' in patch and patch['type']!=item['type']:
                item={'type':patch['type'],'raw_phrase':item.get('raw_phrase','')}
            item.update(patch)
            d['records'][index]=parse_records([item])[0].to_dict()
            self._conn.execute('UPDATE drafts SET payload=?,revision=revision+1 WHERE id=?',(json.dumps(d['records'],ensure_ascii=False,allow_nan=False),batch))
            self._event(user,'edited',batch,index)
        return self.draft(user,batch)

    def cancel(self,user,batch,revision):
        with self.transaction():
            d=self.draft(user,batch)
            if d['status']=='cancelled': return
            if d['status']!='pending' or d['revision']!=revision: raise Conflict('Карточка устарела')
            self._conn.execute("UPDATE drafts SET status='cancelled',revision=revision+1 WHERE id=?",(batch,))
            for i in range(len(d['records'])): self._event(user,'cancelled',batch,i)

    def _insert(self,user,record,created_at,batch=None,index=None):
        validate_ready(record)
        day=record.date if isinstance(record,EventRecord) else record.due_date if isinstance(record,TaskRecord) else None
        day=day or record.occurred_on or created_at.astimezone(zone(self.user_zone(user) or 'UTC')).date().isoformat()
        cur=self._conn.execute('INSERT INTO records(user_id,type,payload,created_at,day,batch_id,item_index) VALUES(?,?,?,?,?,?,?)',(user,record.type,json.dumps(record.to_dict(),ensure_ascii=False,allow_nan=False),created_at.isoformat(),day,batch,index))
        if isinstance(record,EventRecord) and record.reminder_minutes is not None:
            name=self.user_zone(user)
            if not name: raise ValidationError('Установите часовой пояс перед напоминанием')
            due=datetime.fromisoformat(record.date+'T'+record.time).replace(tzinfo=zone(name)).astimezone(timezone.utc)-timedelta(minutes=record.reminder_minutes)
            if due<=created_at: raise ValidationError('Время напоминания прошло. Исправьте дату или напоминание.')
            self._conn.execute('INSERT INTO reminders(record_id,user_id,due_at) VALUES(?,?,?)',(cur.lastrowid,user,due.isoformat()))
        return cur.lastrowid

    def confirm(self,user,batch,revision):
        self.ensure_user(user)
        with self._lock:
            d=self.draft(user,batch)
            if d['status']=='saved': return [r[0] for r in self._conn.execute('SELECT id FROM records WHERE user_id=? AND batch_id=? ORDER BY item_index',(user,batch))]
            if d['status']!='pending' or d['revision']!=revision: raise Conflict('Карточка устарела или отменена')
            records=parse_records(d['records'])
            for r in records: validate_ready(r)
            now=utcnow(); ids=[]
            # Confirmation intent survives a failed transaction so M-04 can detect
            # the failed save; no personal text is placed in telemetry.
            with self.transaction():
                for i in range(len(records)): self._event(user,'confirmed',batch,i,now)
            with self.transaction():
                for i,r in enumerate(records):
                    ids.append(self._insert(user,r,now,batch,i))
                    self._event(user,'saved',batch,i,now)
                self._conn.execute("UPDATE drafts SET status='saved',revision=revision+1 WHERE id=?",(batch,))
                self._event(user,'active_day',batch,at=now)
            return ids

    def add_records(self,user_id,records,created_at=None):
        self.ensure_user(user_id); now=created_at or utcnow()
        if now.tzinfo is None: now=now.replace(tzinfo=timezone.utc)
        with self.transaction(): return [self._insert(user_id,r,now) for r in records]

    def add_record(self,user_id,record,created_at=None): return self.add_records(user_id,[record],created_at)[0]

    def list_records(self,user,kind=None,day=None):
        sql='SELECT id,payload,day,created_at FROM records WHERE user_id=?'; args=[user]
        if kind: sql+=' AND type=?'; args.append(kind)
        if day: sql+=' AND day=?'; args.append(str(day))
        with self._lock:
            return [dict(json.loads(r['payload']),id=r['id'],day=r['day'],created_at=r['created_at']) for r in self._conn.execute(sql+' ORDER BY day,id',args)]

    def get_today(self,user_id,today=None):
        return parse_records([{k:v for k,v in r.items() if k not in ('id','day','created_at')} for r in self.list_records(user_id,day=today or self.today(user_id))])

    def get_summary(self,user_id,today=None):
        grouped=defaultdict(list)
        for r in self.get_today(user_id,today): grouped[r.type].append(r)
        return dict(grouped)

    def claim_reminders(self,now=None):
        now=now or utcnow(); rows=[]
        with self.transaction():
            candidates=self._conn.execute("SELECT m.*,r.payload FROM reminders m JOIN records r ON r.id=m.record_id WHERE (m.status='pending' OR (m.status='sending' AND m.claimed_at<?)) AND m.due_at<=? AND (m.last_attempt IS NULL OR m.last_attempt<?) AND m.attempts<5",((now-timedelta(minutes=2)).isoformat(),now.isoformat(),(now-timedelta(seconds=30)).isoformat())).fetchall()
            for row in candidates:
                self._conn.execute("UPDATE reminders SET status='sending',attempts=attempts+1,claimed_at=?,last_attempt=? WHERE record_id=?",(now.isoformat(),now.isoformat(),row['record_id']))
                rows.append(dict(row))
        return rows

    def reminder_result(self,record_id,success):
        with self.transaction():
            if success: self._conn.execute("UPDATE reminders SET status='sent' WHERE record_id=?",(record_id,))
            else: self._conn.execute("UPDATE reminders SET status=CASE WHEN attempts>=5 THEN 'failed' ELSE 'pending' END WHERE record_id=?",(record_id,))

    def setting(self,key,value=None):
        with self._lock:
            if value is not None: self._conn.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',(key,str(value)))
            row=self._conn.execute('SELECT value FROM settings WHERE key=?',(key,)).fetchone()
            return row[0] if row else None

    def metrics(self,now=None):
        now=now or utcnow()
        with self._lock:
            users=[dict(r) for r in self._conn.execute('SELECT * FROM users')]
            events=[dict(r) for r in self._conn.execute('SELECT * FROM analytics')]
            records=list(self._conn.execute('SELECT batch_id,item_index FROM records'))
            reviews=list(self._conn.execute('SELECT major_error FROM reviews'))
        def ratio(a,b): return round(a/b,6) if b else None
        matured=[u for u in users if datetime.fromisoformat(u['first_seen'])+timedelta(hours=24)<=now]
        activated=0; weekly=[]
        for u in users:
            start=datetime.fromisoformat(u['first_seen']); end=start+timedelta(days=7)
            saved=[datetime.fromisoformat(e['at']) for e in events if e['user_id']==u['id'] and e['event']=='saved']
            if u in matured and any(start<=t<start+timedelta(hours=24) for t in saved): activated+=1
            if end<=now and any(start<=t<end for t in saved):
                weekly.append(len({int((t-start).total_seconds()//86400) for t in saved if start<=t<end}))
        proposed={(e['batch_id'],e['item_index']) for e in events if e['event']=='proposed'}
        edited={(e['batch_id'],e['item_index']) for e in events if e['event']=='edited'}
        confirmed={(e['batch_id'],e['item_index']) for e in events if e['event']=='confirmed'}
        saved={(r[0],r[1]) for r in records if r[0]}
        return {'M-01':ratio(activated,len(matured)),'M-02':ratio(sum(weekly),len(weekly)),'M-03':ratio(len(saved-edited),len(proposed)),'M-04':ratio(len(confirmed-saved),len(confirmed)),'M-05':ratio(sum(r[0] for r in reviews),len(reviews)),'sample':{'matured_24h_users':len(matured),'matured_week_users':len(weekly),'proposed':len(proposed),'reviewed':len(reviews)},'note':'null: недостаточно данных. Цели не являются результатами пилота.'}
