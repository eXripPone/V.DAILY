"""Dependency-free local server and Telegram Mini App API."""
import argparse,json,logging,mimetypes,os,secrets,sqlite3,threading,time
from collections import defaultdict,deque
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse,parse_qs
from app.auth import AuthError,Sessions,validate_init_data
from app.llm_parser import AnthropicLLMClient,ParsingError
from app.models import ValidationError
from app.service import DemoClient,Service,draft_public
from app.storage import Storage,Conflict,NotFound

STATIC=Path(__file__).parent/'static'

class Application:
    def __init__(self,db='vdaily.sqlite3',demo=False,bot_token='',api_key='',model='claude-sonnet-4-6',public_url='',trust_proxy=False):
        self.demo=demo; self.bot_token=bot_token; self.public_url=public_url.rstrip('/'); self.trust_proxy=trust_proxy
        self.storage=Storage(db); self.sessions=Sessions()
        self.service=Service(self.storage,DemoClient() if demo else AnthropicLLMClient(api_key,model))
        self.rate=defaultdict(deque); self.rate_lock=threading.Lock()
        self.worker_slots=threading.BoundedSemaphore(4)

    def allow(self,key):
        with self.rate_lock:
            now=time.monotonic(); q=self.rate[key]
            while q and q[0]<now-60: q.popleft()
            if len(q)>=120: return False
            q.append(now); return True

def handler_for(app):
    class Handler(BaseHTTPRequestHandler):
        server_version='VDAILY'
        def log_message(self,*args): pass  # Never log initData, tokens or personal payloads.
        def reply(self,status,data,content_type='application/json; charset=utf-8'):
            body=data if isinstance(data,bytes) else json.dumps(data,ensure_ascii=False,allow_nan=False).encode()
            self.send_response(status)
            for k,v in {'Content-Type':content_type,'Content-Length':str(len(body)),'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'self'; script-src 'self' https://telegram.org; connect-src 'self'; style-src 'self'; img-src 'self' data:; frame-ancestors https://web.telegram.org https://*.telegram.org",'Strict-Transport-Security':'max-age=31536000'}.items(): self.send_header(k,v)
            self.end_headers(); self.wfile.write(body)
        def do_GET(self): self.dispatch()
        def do_POST(self): self.dispatch()
        def dispatch(self):
            try: self.route()
            except AuthError as exc: self.reply(401,{'error':str(exc)})
            except NotFound as exc: self.reply(404,{'error':str(exc)})
            except Conflict as exc: self.reply(409,{'error':str(exc)})
            except (ValidationError,ParsingError) as exc: self.reply(400,{'error':str(exc)})
            except (ValueError,KeyError,TypeError,IndexError): self.reply(400,{'error':'Проверьте формат запроса'})
            except Exception as exc:
                logging.warning('Request failed: %s',type(exc).__name__)
                self.reply(503,{'error':'Не удалось завершить операцию. Данные черновика сохранены; повторите попытку.'})
        def route(self):
            parsed=urlparse(self.path); path=parsed.path
            if path=='/health' and self.command=='GET':
                with app.storage._lock: app.storage._conn.execute('SELECT 1').fetchone()
                self.reply(200,{'status':'ok','mode':'demo' if app.demo else 'live'}); return
            if not path.startswith('/api/'):
                files={'/':'index.html','/app.js':'app.js','/style.css':'style.css'}
                if self.command!='GET' or path not in files: self.reply(404,{'error':'Не найдено'}); return
                filename=STATIC/files[path]
                self.reply(200,filename.read_bytes(),mimetypes.guess_type(str(filename))[0]+'; charset=utf-8'); return
            expected_origin=app.public_url or f'http://{self.headers.get("Host","")}'
            origin=self.headers.get('Origin')
            if origin and origin!=expected_origin: raise AuthError('Недопустимый источник запроса')
            if not app.demo:
                secure=app.trust_proxy and self.client_address[0] in ('127.0.0.1','::1') and self.headers.get('X-Forwarded-Proto')=='https'
                if not secure: raise AuthError('Закрытые данные доступны только через HTTPS-прокси')
            if not app.allow(self.client_address[0]): self.reply(429,{'error':'Слишком много запросов. Подождите минуту.'}); return
            data={}
            if self.command=='POST':
                length=int(self.headers.get('Content-Length','0'))
                if not 0<length<=65536: raise ValidationError('Недопустимый размер запроса')
                data=json.loads(self.rfile.read(length))
                if not isinstance(data,dict): raise ValidationError('Ожидается JSON-объект')
            if path=='/api/config' and self.command=='GET': self.reply(200,{'demo':app.demo}); return
            if path=='/api/session' and self.command=='POST':
                user=validate_init_data(data.get('init_data'),app.bot_token)
                app.storage.ensure_user(user); self.reply(200,{'token':app.sessions.create(user)}); return
            if path=='/api/demo-session' and self.command=='POST':
                if not app.demo or self.client_address[0] not in ('127.0.0.1','::1'): raise AuthError('Деморежим недоступен')
                app.storage.ensure_user(1); self.reply(200,{'token':app.sessions.create(1)}); return
            bearer=self.headers.get('Authorization','')
            if not bearer.startswith('Bearer '): raise AuthError('Требуется авторизация')
            user=app.sessions.user(bearer[7:])
            if path=='/api/profile':
                if self.command=='POST': app.storage.set_zone(user,data['timezone'])
                self.reply(200,{'timezone':app.storage.user_zone(user),'today':app.storage.today(user).isoformat()}); return
            if path=='/api/records' and self.command=='GET':
                query=parse_qs(parsed.query)
                self.reply(200,app.service.feed(user,query.get('view',['today'])[0],query.get('day',[None])[0])); return
            if path=='/api/parse' and self.command=='POST':
                if not app.worker_slots.acquire(blocking=False): self.reply(429,{'error':'Обработка занята. Повторите через несколько секунд.'}); return
                try: result=draft_public(app.service.propose(user,data['text']))
                finally: app.worker_slots.release()
                self.reply(200,result); return
            parts=path.strip('/').split('/')
            if len(parts) in (3,4) and parts[:2]==['api','drafts']:
                batch=parts[2]
                if self.command=='GET' and len(parts)==3: self.reply(200,draft_public(app.storage.draft(user,batch))); return
                if self.command=='POST' and len(parts)==4:
                    revision=data['revision']
                    if type(revision) is not int: raise ValidationError('Нужна версия карточки')
                    if parts[3]=='confirm': self.reply(200,{'ids':app.storage.confirm(user,batch,revision)}); return
                    if parts[3]=='cancel': app.storage.cancel(user,batch,revision); self.reply(200,{'cancelled':True}); return
                    if parts[3]=='edit':
                        index=data['index']
                        if type(index) is not int: raise ValidationError('Некорректный номер записи')
                        self.reply(200,draft_public(app.service.edit(user,batch,index,data['patch'],revision))); return
            self.reply(404,{'error':'Не найдено'})
    return Handler

def create_server(app,host='127.0.0.1',port=8080):
    if app.demo and host not in ('127.0.0.1','localhost','::1'): raise ValueError('Деморежим доступен только на localhost')
    server=ThreadingHTTPServer((host,port),handler_for(app)); server.daemon_threads=True
    return server

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--demo',action='store_true'); parser.add_argument('--port',type=int,default=8080); parser.add_argument('--db',default='vdaily.sqlite3'); args=parser.parse_args()
    token=os.getenv('TELEGRAM_BOT_TOKEN',''); key=os.getenv('ANTHROPIC_API_KEY',''); public=os.getenv('VDAILY_PUBLIC_URL','')
    if not args.demo and (not token or not key or not public.startswith('https://')): parser.error('Для live задайте TELEGRAM_BOT_TOKEN, ANTHROPIC_API_KEY, VDAILY_PUBLIC_URL=https://...')
    app=Application(args.db,args.demo,token,key,os.getenv('ANTHROPIC_MODEL','claude-sonnet-4-6'),public,os.getenv('VDAILY_TRUST_PROXY')=='1')
    if not args.demo:
        from app.bot import TelegramWorker
        worker=TelegramWorker(app)
        threading.Thread(target=worker.run,daemon=True).start()
        threading.Thread(target=worker.reminders,daemon=True).start()
    server=create_server(app,port=args.port)
    print(f'V.DAILY {"DEMO (локальные правила)" if args.demo else "LIVE"}: http://127.0.0.1:{args.port}',flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close(); app.storage.close()

if __name__=='__main__': main()
