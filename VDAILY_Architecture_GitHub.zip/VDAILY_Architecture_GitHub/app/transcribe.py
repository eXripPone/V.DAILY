"""
Речь -> текст.

В MVP это внешний сервис (Whisper или Yandex SpeechKit), поэтому здесь —
только интерфейс и боевая заглушка. FakeTranscriber нужен для тестов и
demo.py, чтобы не записывать настоящий голос ради проверки пайплайна.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


class Transcriber(Protocol):
    def transcribe(self, audio_path: str) -> str:
        ...


@dataclass
class FakeTranscriber:
    """Возвращает заранее заданный текст — для тестов и демонстрации."""

    fixed_text: str

    def transcribe(self, audio_path: str) -> str:
        return self.fixed_text


class WhisperTranscriber:
    """
    Боевая реализация поверх локального whisper или API-обёртки над ним.
    Конкретный провайдер — решение для этапа интеграции, не для MVP-скелета.
    """

    def __init__(self, model_name: str = "base") -> None:
        self._model_name = model_name
        self._model = None  # лениво загружается в transcribe()

    def transcribe(self, audio_path: str) -> str:
        if self._model is None:
            import whisper  # пакет ставится отдельно: pip install openai-whisper

            self._model = whisper.load_model(self._model_name)
        result = self._model.transcribe(audio_path, language="ru")
        return result["text"]
