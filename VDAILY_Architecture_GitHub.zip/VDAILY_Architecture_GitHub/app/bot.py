"""Telegram long polling adapter; workers never block the Mini App server."""
import json,logging,tempfile,threading,time,urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from app.models import ValidationError,parse_records,missing_fields
from app.llm_parser import ParsingError
from app.confirmation import describe
from app.transcribe import WhisperTranscriber

HELP=('Привет! Это V.DAILY. Отправь текст или голос — я предложу встречи, дела, расходы, еду и заметки. '
      'Все записи сохраняются только после подтверждения.\n\n'
      '/tz Europe/Moscow — часовой пояс\n/today — сегодня\n/calendar YYYY-MM-DD — календарь\n'
      '/finance — расходы\n/history — все записи\n/drafts — черновики\n/cancel — выйти из редактирования')

def card(draft):
    lines=['Проверьте записи перед сохранением:']
    for i,r in enumerate(parse_records(draft['records'])):
        title,detail=describe(r)
        lines.append(f'{i+1}. {title[:85]}\n{detail[:140]}')
        missing=missing_fields(r)
        if missing: lines.append('Уточните: '+', '.join(missing))
    return '\n\n'.join(lines)[:3900]

def keyboard(draft):
    batch=draft['id']; rev=draft['revision']
    return {'inline_keyboard':[[{'text':f'Изменить запись {i+1}','callback_data':f'edit:{batch}:{rev}:{i}'}] for i in range(len(draft['records']))]+[[{'text':'Сохранить всё','callback_data':f'confirm:{batch}:{rev}'},{'text':'Отменить','callback_data':f'cancel:{batch}:{rev}'}]]}

class TelegramWorker:
    def __init__(self,app):
        self.app=app; self.transcriber=WhisperTranscriber(); self.locks={}; self.locks_lock=threading.Lock()
        self.pool=ThreadPoolExecutor(max_workers=4)

    def api(self,method,data):
        request=urllib.request.Request(f'https://api.telegram.org/bot{self.app.bot_token}/{method}',data=json.dumps(data,ensure_ascii=False).encode(),headers={'Content-Type':'application/json'})
        with urllib.request.urlopen(request,timeout=40) as response: body=json.load(response)
        if not body.get('ok'): raise RuntimeError('Telegram request failed')
        return body['result']

    def send(self,chat,text,markup=None):
        payload={'chat_id':chat,'text':text[:4000]}
        if markup: payload['reply_markup']=markup
        return self.api('sendMessage',payload)

    def show(self,user,draft): return self.send(user,card(draft),keyboard(draft))

    def handle(self,update):
        message=update.get('message'); callback=update.get('callback_query')
        actor=(message or callback or {}).get('from',{})
        user=actor.get('id')
        chat=(message or (callback or {}).get('message',{})).get('chat',{})
        if not user or chat.get('type')!='private' or chat.get('id')!=user: return
        with self.locks_lock: lock=self.locks.setdefault(user,threading.Lock())
        with lock:
            key='update:'+str(update['update_id'])
            if self.app.storage.setting(key): return
            try:
                self.app.storage.ensure_user(user)
                if callback: self.callback(user,callback)
                else: self.message(user,message)
                self.app.storage.setting(key,'done')
            except (ValidationError,ParsingError) as exc:
                self.send(user,str(exc)); self.app.storage.setting(key,'done')
            except Exception as exc:
                logging.warning('Telegram operation failed: %s',type(exc).__name__)
                try: self.send(user,'Не удалось завершить операцию. Черновик не удалён. Попробуйте ещё раз или откройте /drafts.')
                except Exception: pass

    def message(self,user,message):
        text=message.get('text','').strip(); storage=self.app.storage
        if text.startswith('/start'):
            markup={'inline_keyboard':[[{'text':'Открыть V.DAILY','web_app':{'url':self.app.public_url}}]]} if self.app.public_url else None
            self.send(user,HELP,markup)
            if not storage.user_zone(user): self.send(user,'Выберите часовой пояс: /tz Europe/Moscow (или другой IANA-пояс).')
            return
        if text=='/cancel': storage.set_state(user,None); self.send(user,'Редактирование завершено. Черновик доступен в /drafts.'); return
        if text.startswith('/tz '):
            storage.set_zone(user,text[4:].strip()); self.send(user,'Часовой пояс сохранён. Можно отправлять текст и голос.'); return
        if text=='/drafts':
            drafts=storage.pending(user)
            if not drafts: self.send(user,'Нет неподтверждённых записей.')
            for d in drafts[-10:]: self.show(user,d)
            return
        if text.split(' ')[0] in ('/today','/calendar','/finance','/history'):
            view={'/today':'today','/calendar':'calendar','/finance':'finance','/history':'history'}[text.split(' ')[0]]
            day=text.split(' ',1)[1] if ' ' in text else None
            rows=self.app.service.feed(user,view,day)['records']
            if not rows: self.send(user,'Здесь пока нет записей. Отправьте сообщение и подтвердите результат.'); return
            for start in range(0,len(rows),15):
                lines=[]
                for row in rows[start:start+15]:
                    r=parse_records([{k:v for k,v in row.items() if k not in ('id','day','created_at')}])[0]
                    title,detail=describe(r); lines.append(f'{row["day"]} · {title[:90]}\n{detail[:120]}')
                self.send(user,'\n\n'.join(lines))
            return
        state=storage.get_state(user)
        if state and text:
            if text.startswith('{'): patch=json.loads(text)
            elif '=' in text:
                name,value=text.split('=',1); name=name.strip(); value=value.strip()
                if name in ('amount','calories_kcal','protein_g','fat_g','carbs_g','portion_g'): value=float(value.replace(',','.'))
                elif name=='reminder_minutes': value=int(value)
                elif value.lower()=='null': value=None
                patch={name:value}
            else: raise ValidationError('Введите поле=значение, например amount=500; /cancel — выход.')
            d=self.app.service.edit(user,state['batch'],state['index'],patch,state['revision'])
            storage.set_state(user,None); self.show(user,d); return
        if text.startswith('/'): self.send(user,HELP); return
        if 'voice' in message:
            voice=message['voice']
            if voice.get('file_size',0)>10_000_000 or voice.get('duration',0)>180: raise ValidationError('Голос: до 3 минут и 10 МБ. Для нормативов скорости — до 60 секунд.')
            file=self.api('getFile',{'file_id':voice['file_id']})
            with tempfile.TemporaryDirectory(prefix='vdaily_audio_') as folder:
                path=Path(folder)/'voice.oga'
                with urllib.request.urlopen(f'https://api.telegram.org/file/bot{self.app.bot_token}/{file["file_path"]}',timeout=20) as response:
                    audio=response.read(10_000_001)
                if len(audio)>10_000_000: raise ValidationError('Голосовой файл слишком большой')
                path.write_bytes(audio)
                try: text=self.transcriber.transcribe(str(path))
                except Exception: raise ValidationError('Не удалось распознать голос. Повторите ввод или отправьте текст.') from None
        if text: self.show(user,self.app.service.propose(user,text))

    def callback(self,user,callback):
        self.api('answerCallbackQuery',{'callback_query_id':callback['id']})
        parts=callback.get('data','').split(':')
        if len(parts)<3: raise ValidationError('Некорректная кнопка')
        action,batch,revision=parts[:3]; revision=int(revision)
        d=self.app.storage.draft(user,batch)
        if action=='confirm':
            ids=self.app.storage.confirm(user,batch,revision)
            self.send(user,f'Сохранено записей: {len(ids)}. Просмотр: /today или /history')
        elif action=='cancel':
            self.app.storage.cancel(user,batch,revision); self.send(user,'Набор отменён. Записи не сохранены.')
        elif action=='edit':
            if d['status']!='pending' or revision!=d['revision']: raise ValidationError('Карточка устарела. Откройте /drafts.')
            index=int(parts[3])
            if not 0<=index<len(d['records']): raise ValidationError('Нет такой записи')
            self.app.storage.set_state(user,{'batch':batch,'index':index,'revision':revision})
            keys=', '.join(k for k in d['records'][index] if k not in ('raw_phrase','confidence','type'))
            self.send(user,'Измените поле: '+keys+'\nПримеры: amount=500; date=2026-12-01; time=15:00.\nДля смены категории отправьте JSON с type и полями нового типа. /cancel — выход.')

    def run(self):
        offset=int(self.app.storage.setting('telegram_offset') or 0)
        while True:
            try:
                updates=self.api('getUpdates',{'offset':offset,'timeout':25,'allowed_updates':['message','callback_query']})
                jobs=[self.pool.submit(self.handle,u) for u in updates]
                for job in jobs: job.result()
                if updates:
                    offset=updates[-1]['update_id']+1
                    self.app.storage.setting('telegram_offset',offset)
            except Exception as exc:
                logging.warning('Polling failed: %s',type(exc).__name__); time.sleep(3)

    def reminders(self):
        while True:
            try:
                self.send_due_reminders()
            except Exception as exc: logging.warning('Reminder worker failed: %s',type(exc).__name__)
            time.sleep(5)

    def send_due_reminders(self,now=None):
        for row in self.app.storage.claim_reminders(now):
            try:
                payload=json.loads(row['payload'])
                self.send(row['user_id'],f'Напоминание: {payload["title"]}\n{payload["date"]} · {payload["time"]}')
                success=True
            except Exception: success=False
            self.app.storage.reminder_result(row['record_id'],success)

if __name__=='__main__':
    from app.server import main
    main()
