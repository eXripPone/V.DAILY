"""Telegram Mini App initData validation; no trust in client-supplied user IDs."""
import hashlib,hmac,json,secrets,time,threading
from urllib.parse import parse_qsl

class AuthError(ValueError): pass

def validate_init_data(data,bot_token,now=None,max_age=3600):
    if not bot_token or not isinstance(data,str) or len(data)>16000: raise AuthError('Некорректная авторизация')
    pairs=parse_qsl(data,keep_blank_values=True)
    if len(pairs)!=len(dict(pairs)): raise AuthError('Повторяющиеся параметры')
    values=dict(pairs); supplied=values.pop('hash','')
    check='\n'.join(f'{k}={v}' for k,v in sorted(values.items()))
    secret=hmac.new(b'WebAppData',bot_token.encode(),hashlib.sha256).digest()
    expected=hmac.new(secret,check.encode(),hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected,supplied): raise AuthError('Подпись Telegram недействительна')
    try:
        age=(now if now is not None else time.time())-int(values['auth_date'])
        user=json.loads(values['user'])['id']
        if not 0<=age<=max_age or type(user) is not int or user<=0: raise ValueError()
    except (ValueError,KeyError,TypeError): raise AuthError('Авторизация истекла или некорректна') from None
    return user

class Sessions:
    def __init__(self): self.items={}; self.lock=threading.Lock()
    def create(self,user):
        token=secrets.token_urlsafe(32)
        with self.lock:
            self.items={k:v for k,v in self.items.items() if v[1]>time.time()}
            self.items[token]=(user,time.time()+3600)
        return token
    def user(self,token):
        with self.lock: item=self.items.get(token)
        if not item or item[1]<time.time(): raise AuthError('Откройте приложение заново для авторизации')
        return item[0]
