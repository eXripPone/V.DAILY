import unittest

from app.models import (
    EventRecord,
    ExpenseRecord,
    MealRecord,
    NoteRecord,
    TaskRecord,
    ValidationError,
    parse_records,
)


class TestEventRecord(unittest.TestCase):
    def test_valid_event(self):
        e = EventRecord(title="Встреча с Андреем", date="2026-10-19", time="15:00")
        self.assertEqual(e.type, "event")
        self.assertEqual(e.to_dict()["title"], "Встреча с Андреем")

    def test_empty_title_rejected(self):
        with self.assertRaises(ValidationError):
            EventRecord(title="   ")

    def test_bad_date_format_rejected(self):
        with self.assertRaises(ValidationError):
            EventRecord(title="Встреча", date="19.10.2026")

    def test_bad_time_format_rejected(self):
        with self.assertRaises(ValidationError):
            EventRecord(title="Встреча", time="3pm")

    def test_date_and_time_are_optional(self):
        e = EventRecord(title="Встреча без деталей")
        self.assertIsNone(e.date)
        self.assertIsNone(e.time)


class TestTaskRecord(unittest.TestCase):
    def test_default_priority_is_normal(self):
        t = TaskRecord(title="Оплатить интернет")
        self.assertEqual(t.priority, "normal")

    def test_invalid_priority_rejected(self):
        with self.assertRaises(ValidationError):
            TaskRecord(title="Задача", priority="urgent")


class TestExpenseRecord(unittest.TestCase):
    def test_valid_expense(self):
        e = ExpenseRecord(amount=500, category="Транспорт")
        self.assertEqual(e.currency, "RUB")

    def test_non_positive_amount_rejected(self):
        with self.assertRaises(ValidationError):
            ExpenseRecord(amount=0, category="Транспорт")
        with self.assertRaises(ValidationError):
            ExpenseRecord(amount=-100, category="Транспорт")

    def test_empty_category_rejected(self):
        with self.assertRaises(ValidationError):
            ExpenseRecord(amount=100, category="")


class TestMealAndNote(unittest.TestCase):
    def test_meal_without_calories_is_ok(self):
        m = MealRecord(description="Борщ")
        self.assertIsNone(m.calories_kcal)

    def test_meal_negative_calories_rejected(self):
        with self.assertRaises(ValidationError):
            MealRecord(description="Борщ", calories_kcal=-10)

    def test_note_requires_text(self):
        with self.assertRaises(ValidationError):
            NoteRecord(text="")


class TestConfidenceBounds(unittest.TestCase):
    def test_confidence_out_of_range_rejected(self):
        with self.assertRaises(ValidationError):
            NoteRecord(text="что-то", confidence=1.5)
        with self.assertRaises(ValidationError):
            NoteRecord(text="что-то", confidence=-0.1)


class TestParseRecords(unittest.TestCase):
    def test_mixed_list_parsed_into_correct_types(self):
        raw = [
            {"type": "event", "title": "Встреча", "date": "2026-10-19", "time": "15:00"},
            {"type": "expense", "amount": 500, "category": "Транспорт"},
            {"type": "note", "text": "просто мысль"},
        ]
        records = parse_records(raw)
        self.assertEqual([r.type for r in records], ["event", "expense", "note"])

    def test_unknown_type_rejected(self):
        with self.assertRaises(ValidationError):
            parse_records([{"type": "reminder", "title": "???"}])

    def test_non_list_input_rejected(self):
        with self.assertRaises(ValidationError):
            parse_records({"type": "note", "text": "не список"})

    def test_non_dict_item_rejected(self):
        with self.assertRaises(ValidationError):
            parse_records(["просто строка"])

    def test_unexpected_field_rejected(self):
        with self.assertRaises(ValidationError):
            parse_records([{"type": "note", "text": "ок", "extra_field": 123}])


if __name__ == "__main__":
    unittest.main()
