import unittest
from datetime import date, datetime

from app.models import EventRecord, ExpenseRecord, NoteRecord
from app.storage import Storage


class TestStorage(unittest.TestCase):
    def setUp(self):
        self.storage = Storage()  # :memory:
        self.today = date(2026, 10, 18)
        self.now = datetime(2026, 10, 18, 9, 30)

    def tearDown(self):
        self.storage.close()

    def test_add_and_get_today(self):
        self.storage.add_record(1, NoteRecord(text="первая мысль"), created_at=self.now)
        self.storage.add_record(1, NoteRecord(text="вторая мысль"), created_at=self.now)
        records = self.storage.get_today(1, today=self.today)
        self.assertEqual(len(records), 2)
        self.assertEqual(records[0].text, "первая мысль")

    def test_records_from_other_day_not_included(self):
        yesterday = datetime(2026, 10, 17, 9, 0)
        self.storage.add_record(1, NoteRecord(text="вчерашняя мысль"), created_at=yesterday)
        self.storage.add_record(1, NoteRecord(text="сегодняшняя мысль"), created_at=self.now)
        records = self.storage.get_today(1, today=self.today)
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0].text, "сегодняшняя мысль")

    def test_users_are_isolated(self):
        self.storage.add_record(1, NoteRecord(text="для первого"), created_at=self.now)
        self.storage.add_record(2, NoteRecord(text="для второго"), created_at=self.now)
        self.assertEqual(len(self.storage.get_today(1, today=self.today)), 1)
        self.assertEqual(len(self.storage.get_today(2, today=self.today)), 1)

    def test_get_summary_groups_by_type(self):
        self.storage.add_records(
            1,
            [
                EventRecord(title="Встреча", date="2026-10-19", time="15:00"),
                ExpenseRecord(amount=500, category="Транспорт"),
                ExpenseRecord(amount=200, category="Еда"),
            ],
            created_at=self.now,
        )
        summary = self.storage.get_summary(1, today=self.today)
        self.assertEqual(set(summary.keys()), {"expense"})
        self.assertEqual(len(summary["expense"]), 2)
        tomorrow = self.storage.get_summary(1, today=date(2026, 10, 19))
        self.assertEqual(len(tomorrow["event"]), 1)

    def test_empty_day_returns_empty_summary(self):
        self.assertEqual(self.storage.get_today(1, today=self.today), [])
        self.assertEqual(self.storage.get_summary(1, today=self.today), {})


if __name__ == "__main__":
    unittest.main()
