import json
import unittest
from datetime import date

from app.llm_parser import FakeLLMClient, ParsingError, parse_voice_text

REFERENCE_DATE = date(2026, 10, 18)

CANONICAL_RESPONSE = json.dumps(
    [
        {
            "type": "event",
            "title": "Встреча с Андреем",
            "date": "2026-10-19",
            "time": "15:00",
            "with_person": "Андрей",
            "raw_phrase": "завтра в три встреча с Андреем",
            "confidence": 0.93,
        },
        {
            "type": "meal",
            "description": "Борщ",
            "calories_kcal": 350,
            "raw_phrase": "на обед борщ",
            "confidence": 0.8,
        },
        {
            "type": "task",
            "title": "Оплатить интернет",
            "raw_phrase": "не забыть оплатить интернет",
            "confidence": 0.9,
        },
        {
            "type": "expense",
            "amount": 500,
            "category": "Транспорт",
            "raw_phrase": "потратил 500 на такси",
            "confidence": 0.85,
        },
    ],
    ensure_ascii=False,
)

VOICE_TEXT = (
    "Завтра в три встреча с Андреем, на обед борщ, "
    "не забыть оплатить интернет, потратил 500 на такси"
)


class TestParseVoiceTextHappyPath(unittest.TestCase):
    def setUp(self):
        self.client = FakeLLMClient(response=CANONICAL_RESPONSE)

    def test_returns_four_records_of_expected_types(self):
        records = parse_voice_text(VOICE_TEXT, self.client, reference_date=REFERENCE_DATE)
        self.assertEqual([r.type for r in records], ["event", "meal", "task", "expense"])

    def test_event_fields_match_the_scenario(self):
        records = parse_voice_text(VOICE_TEXT, self.client, reference_date=REFERENCE_DATE)
        event = records[0]
        self.assertEqual(event.title, "Встреча с Андреем")
        self.assertEqual(event.date, "2026-10-19")
        self.assertEqual(event.time, "15:00")

    def test_expense_amount_and_category(self):
        records = parse_voice_text(VOICE_TEXT, self.client, reference_date=REFERENCE_DATE)
        expense = records[3]
        self.assertEqual(expense.amount, 500)
        self.assertEqual(expense.category, "Транспорт")


class TestParseVoiceTextRobustness(unittest.TestCase):
    def test_strips_markdown_code_fence(self):
        fenced = f"```json\n{CANONICAL_RESPONSE}\n```"
        client = FakeLLMClient(response=fenced)
        records = parse_voice_text(VOICE_TEXT, client, reference_date=REFERENCE_DATE)
        self.assertEqual(len(records), 4)

    def test_invalid_json_raises_parsing_error(self):
        client = FakeLLMClient(response="это не json, а просто текст")
        with self.assertRaises(ParsingError):
            parse_voice_text(VOICE_TEXT, client, reference_date=REFERENCE_DATE)

    def test_json_failing_model_validation_raises_parsing_error(self):
        bad = json.dumps([{"type": "expense", "amount": -500, "category": "Транспорт"}])
        client = FakeLLMClient(response=bad)
        with self.assertRaises(ParsingError):
            parse_voice_text(VOICE_TEXT, client, reference_date=REFERENCE_DATE)

    def test_empty_voice_text_rejected_without_calling_llm(self):
        client = FakeLLMClient(response="не должно быть вызвано")
        with self.assertRaises(ParsingError):
            parse_voice_text("   ", client, reference_date=REFERENCE_DATE)

    def test_empty_array_response_gives_empty_list(self):
        client = FakeLLMClient(response="[]")
        records = parse_voice_text("бессвязное мычание", client, reference_date=REFERENCE_DATE)
        self.assertEqual(records, [])


if __name__ == "__main__":
    unittest.main()
