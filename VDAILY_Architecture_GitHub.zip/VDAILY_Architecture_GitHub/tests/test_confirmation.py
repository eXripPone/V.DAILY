import unittest

from app.confirmation import build_inline_keyboard, format_confirmation_card, needs_confirmation
from app.models import EventRecord, ExpenseRecord, MealRecord, NoteRecord, TaskRecord


class TestNeedsConfirmation(unittest.TestCase):
    def test_low_confidence_always_flagged(self):
        record = NoteRecord(text="непонятное бормотание", confidence=0.3)
        self.assertTrue(needs_confirmation(record))

    def test_confident_note_requires_confirmation(self):
        record = NoteRecord(text="чёткая мысль", confidence=0.95)
        self.assertTrue(needs_confirmation(record))

    def test_confident_task_requires_confirmation(self):
        record = TaskRecord(title="Оплатить интернет", confidence=0.95)
        self.assertTrue(needs_confirmation(record))

    def test_event_flagged_even_with_high_confidence(self):
        record = EventRecord(title="Встреча", date="2026-10-19", time="15:00", confidence=0.99)
        self.assertTrue(needs_confirmation(record))

    def test_expense_flagged_even_with_high_confidence(self):
        record = ExpenseRecord(amount=500, category="Транспорт", confidence=0.99)
        self.assertTrue(needs_confirmation(record))


class TestFormatConfirmationCard(unittest.TestCase):
    def test_empty_list_gives_friendly_message(self):
        text = format_confirmation_card([])
        self.assertIn("не нашёл", text.lower())

    def test_card_mentions_each_record_and_its_section(self):
        records = [
            EventRecord(title="Встреча с Андреем", date="2026-10-19", time="15:00"),
            MealRecord(description="Борщ", calories_kcal=350),
            TaskRecord(title="Оплатить интернет"),
            ExpenseRecord(amount=500, category="Транспорт"),
        ]
        text = format_confirmation_card(records)
        self.assertIn("Встреча с Андреем", text)
        self.assertIn("Календарь", text)
        self.assertIn("Борщ", text)
        self.assertIn("Питание", text)
        self.assertIn("Оплатить интернет", text)
        self.assertIn("Задачи", text)
        self.assertIn("500", text)
        self.assertIn("Финансы", text)


class TestInlineKeyboard(unittest.TestCase):
    def test_confirm_all_button_present_when_there_are_records(self):
        records = [NoteRecord(text="мысль", confidence=0.95)]
        rows = build_inline_keyboard(records)
        callback_data = [data for row in rows for _, data in row]
        self.assertIn("confirm:preview:0", callback_data)

    def test_every_record_can_be_edited(self):
        records = [
            NoteRecord(text="уверенная заметка", confidence=0.95),
            ExpenseRecord(amount=500, category="Транспорт", confidence=0.95),  # всегда флагуется
        ]
        rows = build_inline_keyboard(records)
        callback_data = [data for row in rows for _, data in row]
        self.assertIn("edit:preview:0:1", callback_data)
        self.assertIn("edit:preview:0:0", callback_data)

    def test_no_buttons_when_no_records(self):
        self.assertEqual(build_inline_keyboard([]), [])


if __name__ == "__main__":
    unittest.main()
