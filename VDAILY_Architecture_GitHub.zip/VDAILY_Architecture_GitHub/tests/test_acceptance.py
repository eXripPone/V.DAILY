"""Acceptance and regression cases mapped to the final SRS identifiers."""
import concurrent.futures
import hashlib,hmac,json,sqlite3,tempfile,threading,time,unittest,urllib.request,urllib.error
from datetime import date,datetime,timedelta,timezone
from pathlib import Path
from urllib.parse import urlencode
from unittest.mock import patch
from app.auth import AuthError,validate_init_data
from app.bot import TelegramWorker,HELP
from app.llm_parser import FakeLLMClient,ParsingError,parse_voice_text
from app.models import EventRecord,ExpenseRecord,MealRecord,NoteRecord,ValidationError,parse_records
from app.server import Application,create_server
from app.service import DemoClient,Service
from app.storage import Storage,Conflict,NotFound,utcnow

def signed(user=42,token='test-token',at=None):
    data={'auth_date':str(int(time.time()) if at is None else at),'user':json.dumps({'id':user},separators=(',',':')),'query_id':'test'}
    secret=hmac.new(b'WebAppData',token.encode(),hashlib.sha256).digest()
    data['hash']=hmac.new(secret,'\n'.join(f'{k}={v}' for k,v in sorted(data.items())).encode(),hashlib.sha256).hexdigest()
    return urlencode(data)

class CoreAcceptance(unittest.TestCase):
    def setUp(self):
        self.db=Storage(); self.db.set_zone(1,'Europe/Moscow'); self.s=Service(self.db,DemoClient())
    def tearDown(self): self.db.close()
    def propose(self,text): return self.s.propose(1,text)

    def test_FR_02_FR_04_FR_05_FR_06_mixed_preview(self):
        d=self.propose('Завтра в 15:00 встреча с Андреем, на обед борщ, не забыть оплатить интернет, потратил 500 на такси')
        self.assertEqual([r['type'] for r in d['records']],['event','meal','task','expense'])
        self.assertEqual(self.db.list_records(1),[])
        self.assertEqual(d['records'][3]['amount'],500)

    def test_FR_07_edit_amount_and_category(self):
        d=self.propose('Потратил 550 на такси')
        changed=self.s.edit(1,d['id'],0,{'amount':500,'category':'Поездки'},d['revision'])
        self.assertEqual(changed['records'][0]['amount'],500)
        with self.assertRaises(Conflict): self.db.confirm(1,d['id'],d['revision'])
        self.db.confirm(1,d['id'],changed['revision'])
        self.assertEqual(self.db.list_records(1)[0]['category'],'Поездки')

    def test_FR_07_change_record_type(self):
        d=self.propose('Заметка: идея')
        d=self.s.edit(1,d['id'],0,{'type':'task','title':'Купить подарок'},0)
        self.assertEqual(d['records'][0]['type'],'task')
        self.db.confirm(1,d['id'],d['revision'])

    def test_FR_08_FR_11_FR_12_old_cards_and_repeat(self):
        a=self.propose('Заметка: А'); b=self.propose('Заметка: Б')
        ids=self.db.confirm(1,a['id'],0)
        self.assertEqual([r['text'] for r in self.db.list_records(1)],['А'])
        self.assertEqual(ids,self.db.confirm(1,a['id'],0))
        self.assertEqual(self.db.draft(1,b['id'])['status'],'pending')
        self.db.confirm(1,b['id'],0)
        self.assertEqual(len(self.db.list_records(1)),2)

    def test_FR_09_cancel_no_save(self):
        d=self.propose('Заметка: отменить'); self.db.cancel(1,d['id'],0)
        with self.assertRaises(Conflict): self.db.confirm(1,d['id'],0)
        self.assertEqual(self.db.list_records(1),[])

    def test_FR_10_missing_amount_then_clarify(self):
        d=self.propose('Потратил на такси')
        self.assertIsNone(d['records'][0]['amount'])
        with self.assertRaises(ValidationError): self.db.confirm(1,d['id'],0)
        d=self.s.edit(1,d['id'],0,{'amount':500},0)
        self.db.confirm(1,d['id'],d['revision'])
        self.assertEqual(self.db.list_records(1)[0]['amount'],500)

    def test_FR_10_FR_25_ambiguous_time(self):
        d=self.propose('Завтра в три встреча с Андреем')
        self.assertIsNone(d['records'][0]['time'])
        with self.assertRaises(ValidationError): self.db.confirm(1,d['id'],0)
        d=self.s.edit(1,d['id'],0,{'time':'15:00'},0)
        self.db.confirm(1,d['id'],d['revision'])

    def test_FR_13_FR_21_FR_22_semantic_date(self):
        today=self.db.today(1); tomorrow=today+timedelta(days=1)
        d=self.propose('Завтра в 15:00 встреча с Андреем'); self.db.confirm(1,d['id'],0)
        self.assertEqual(self.s.feed(1,'today')['records'],[])
        self.assertEqual(len(self.s.feed(1,'calendar',tomorrow.isoformat())['records']),1)

    def test_FR_14_real_reminder_dispatch_and_no_duplicate(self):
        d=self.propose('Завтра в 15:00 встреча с Андреем, напомни за час')
        self.db.confirm(1,d['id'],0)
        rows=self.db.claim_reminders(utcnow()+timedelta(days=2))
        self.assertEqual(len(rows),1)
        expected=datetime.fromisoformat(d['records'][0]['date']+'T14:00:00+03:00').astimezone(timezone.utc)
        self.assertEqual(datetime.fromisoformat(rows[0]['due_at']),expected)
        self.db.reminder_result(rows[0]['record_id'],True)
        self.assertEqual(self.db.claim_reminders(utcnow()+timedelta(days=3)),[])

    def test_FR_14_no_implicit_reminder(self):
        d=self.propose('Завтра в 15:00 встреча'); self.db.confirm(1,d['id'],0)
        self.assertEqual(self.db.claim_reminders(utcnow()+timedelta(days=5)),[])

    def test_FR_15_FR_23_finance_date(self):
        d=self.propose('Потратил 500 на такси'); self.db.confirm(1,d['id'],0)
        row=self.s.feed(1,'finance')['records'][0]
        self.assertEqual((row['amount'],row['currency'],row['category']),(500,'RUB','Транспорт'))
        self.assertEqual(row['day'],self.db.today(1).isoformat())

    def test_FR_16_task_with_and_without_deadline(self):
        for text in ('Не забыть оплатить интернет','Задача: завтра оплатить интернет'):
            d=self.propose(text); self.db.confirm(1,d['id'],0)
        tasks=self.db.list_records(1,'task')
        self.assertIsNone(tasks[0]['due_date']); self.assertIsNotNone(tasks[1]['due_date'])

    def test_FR_17_FR_18_meal_four_values_and_portion(self):
        d=self.propose('На обед борщ')
        for name in ('calories_kcal','protein_g','fat_g','carbs_g','portion_g'): self.assertGreater(d['records'][0][name],0)
        self.assertTrue(d['records'][0]['estimated'])
        self.db.confirm(1,d['id'],0)

    def test_FR_19_note_history(self):
        d=self.propose('Заметка: идея для подарка'); self.db.confirm(1,d['id'],0)
        self.assertEqual(self.s.feed(1,'history')['records'][0]['text'],'идея для подарка')

    def test_FR_24_NFR_06_analytics_edits_cancel_and_no_personal_text(self):
        a=self.propose('Потратил 500 на такси'); b=self.propose('Заметка: секрет')
        a=self.s.edit(1,a['id'],0,{'amount':400},0); self.db.confirm(1,a['id'],1); self.db.cancel(1,b['id'],0)
        telemetry=json.dumps([dict(r) for r in self.db._conn.execute('SELECT * FROM analytics')])
        self.assertNotIn('секрет',telemetry); self.assertNotIn('такси',telemetry)
        self.assertEqual(self.db.metrics()['M-03'],0)

    def test_FR_25_timezone_required_and_midnight(self):
        with self.assertRaises(ValidationError): self.s.propose(2,'Завтра встреча')
        now=datetime(2026,10,18,22,30,tzinfo=timezone.utc)
        self.assertEqual(self.db.today(1,now),date(2026,10,19))

    def test_FR_26_provider_failures_are_sanitized(self):
        class Broken:
            def complete(self,*args): raise RuntimeError('PRIVATE TEXT AND KEY')
        with self.assertRaises(ParsingError) as error: parse_voice_text('привет',Broken())
        self.assertNotIn('PRIVATE',str(error.exception))
        with self.assertRaises(ParsingError) as error: parse_voice_text('привет',FakeLLMClient('PRIVATE NON JSON'))
        self.assertNotIn('PRIVATE',str(error.exception))

    def test_FR_27_text_and_transcript_boundaries(self):
        fake=FakeLLMClient('[{"type":"note","text":"ok"}]')
        for label in ('text','voice transcript'):
            with self.subTest(label=label):
                self.assertEqual(len(parse_voice_text('x'*1000,fake)),1)
                with self.assertRaises(ParsingError): parse_voice_text('x'*1001,fake)

    def test_NFR_05_atomic_failure_draft_survives_and_retry(self):
        d=self.propose('Заметка: первая, потратил 500 на такси')
        self.db._conn.execute("CREATE TRIGGER fail_expense BEFORE INSERT ON records WHEN NEW.type='expense' BEGIN SELECT RAISE(FAIL,'test'); END")
        with self.assertRaises(sqlite3.IntegrityError): self.db.confirm(1,d['id'],0)
        self.assertEqual(self.db.list_records(1),[])
        self.assertEqual(self.db.draft(1,d['id'])['status'],'pending')
        self.assertEqual(self.db.metrics()['M-04'],1)
        self.db._conn.execute('DROP TRIGGER fail_expense')
        self.db.confirm(1,d['id'],0)
        self.assertEqual(len(self.db.list_records(1)),2)
        self.assertEqual(self.db.metrics()['M-04'],0)

    def test_NFR_05_concurrent_confirm_single_batch(self):
        d=self.propose('Заметка: одна')
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            ids=list(pool.map(lambda _:self.db.confirm(1,d['id'],0),range(20)))
        self.assertTrue(all(r==ids[0] for r in ids)); self.assertEqual(len(self.db.list_records(1)),1)

    def test_NFR_07_reject_invalid_values(self):
        for value in (float('nan'),float('inf'),True,-1,0):
            with self.subTest(value=value),self.assertRaises(ValidationError): ExpenseRecord(amount=value)
        with self.assertRaises(ValidationError): EventRecord(title='X',date='2026-02-31')
        with self.assertRaises(ValidationError): ExpenseRecord(amount=1,currency='USD')
        d=self.db.new_draft(1,[EventRecord(title='No date')])
        with self.assertRaises(ValidationError): self.db.confirm(1,d['id'],0)

    def test_NFR_08_cross_user_cannot_read_edit_confirm_cancel(self):
        d=self.propose('Заметка: secret')
        for op in (lambda:self.db.draft(2,d['id']),lambda:self.db.edit_draft(2,d['id'],0,{'text':'x'},0),lambda:self.db.confirm(2,d['id'],0),lambda:self.db.cancel(2,d['id'],0)):
            with self.assertRaises(NotFound): op()
        self.assertEqual(self.db.list_records(2),[])

    def test_NFR_09_telegram_signatures_expiry_and_duplicate_keys(self):
        valid=signed(); self.assertEqual(validate_init_data(valid,'test-token'),42)
        for invalid in (valid+'x',signed(at=1),valid+'&auth_date=1',signed(at=int(time.time())+60)):
            with self.assertRaises(AuthError): validate_init_data(invalid,'test-token')

    def test_NFR_11_russian_relative_dates(self):
        d=self.propose('Послезавтра в 15:00 встреча')
        self.assertEqual(d['records'][0]['date'],(self.db.today(1)+timedelta(days=2)).isoformat())

    def test_drafts_and_idempotency_survive_restart(self):
        with tempfile.TemporaryDirectory() as folder:
            path=str(Path(folder)/'db.sqlite'); db=Storage(path); db.set_zone(1,'Europe/Moscow')
            draft=db.new_draft(1,[NoteRecord(text='persistent')]); db.close()
            db=Storage(path); ids=db.confirm(1,draft['id'],0); db.close()
            db=Storage(path); self.assertEqual(db.confirm(1,draft['id'],0),ids); db.close()

    def test_metrics_empty_data_not_fabricated(self):
        metrics=self.db.metrics(); self.assertIsNone(metrics['M-01']); self.assertIsNone(metrics['M-02']); self.assertIsNone(metrics['M-05'])

    def test_FR_24_mature_cohorts_and_manual_review(self):
        start=utcnow()-timedelta(days=8)
        self.db._conn.execute('UPDATE users SET first_seen=? WHERE id=1',(start.isoformat(),))
        d=self.propose('Заметка: когорта'); ids=self.db.confirm(1,d['id'],0)
        self.db._conn.execute("UPDATE analytics SET at=? WHERE event='saved'",((start+timedelta(hours=1)).isoformat(),))
        self.db._conn.execute('INSERT INTO reviews VALUES(?,1)',(ids[0],))
        m=self.db.metrics()
        self.assertEqual(m['M-01'],1)
        self.assertEqual(m['M-02'],1)
        self.assertEqual(m['M-05'],1)

class HTTPAcceptance(unittest.TestCase):
    def setUp(self):
        self.app=Application(':memory:',demo=True)
        self.server=create_server(self.app,port=0)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True); self.thread.start()
        self.base='http://127.0.0.1:'+str(self.server.server_port)
        self.token=self.request('/api/demo-session',{})[1]['token']
    def tearDown(self): self.server.shutdown(); self.server.server_close(); self.thread.join(); self.app.storage.close()
    def request(self,path,data=None,token=None,headers=None):
        h={'Content-Type':'application/json',**(headers or {})}
        token=token if token is not None else getattr(self,'token','')
        if token: h['Authorization']='Bearer '+token
        req=urllib.request.Request(self.base+path,data=None if data is None else json.dumps(data).encode(),headers=h)
        try: response=urllib.request.urlopen(req,timeout=5)
        except urllib.error.HTTPError as e: response=e
        body=response.read(); status=response.status
        return status,json.loads(body) if response.headers.get_content_type()=='application/json' else body

    def test_FR_20_FR_21_FR_22_FR_23_HTTP_full_flow(self):
        self.assertEqual(self.request('/api/profile',{'timezone':'Europe/Moscow'})[0],200)
        status,d=self.request('/api/parse',{'text':'Потратил 500 на такси'})
        self.assertEqual(status,200)
        self.assertEqual(self.request('/api/records?view=finance')[1]['records'],[])
        self.assertEqual(self.request('/api/drafts/'+d['id']+'/confirm',{'revision':0})[0],200)
        for view in ('today','finance','history'):
            self.assertEqual(len(self.request('/api/records?view='+view)[1]['records']),1)
        self.assertEqual(self.request('/api/records?view=calendar')[1]['records'],[])
        self.assertEqual(self.request('/')[0],200)

    def test_NFR_08_HTTP_auth_and_cross_user(self):
        self.assertEqual(self.request('/api/records',token='bad')[0],401)
        other=self.app.sessions.create(2)
        self.request('/api/profile',{'timezone':'Europe/Moscow'})
        d=self.request('/api/parse',{'text':'Заметка: secret'})[1]
        self.assertEqual(self.request('/api/drafts/'+d['id'],token=other)[0],404)

    def test_NFR_10_live_HTTP_refused_and_origin_guard(self):
        self.app.demo=False
        self.assertEqual(self.request('/api/profile')[0],401)
        self.app.demo=True
        self.assertEqual(self.request('/api/parse',{'text':'test'},headers={'Origin':'https://evil.example'})[0],401)

    def test_NFR_09_HTTP_live_valid_signature_session_and_owner(self):
        self.app.demo=False; self.app.bot_token='test-token'; self.app.trust_proxy=True
        headers={'X-Forwarded-Proto':'https'}
        status,session=self.request('/api/session',{'init_data':signed(42),'user_id':999},headers=headers)
        self.assertEqual(status,200)
        self.assertEqual(self.app.sessions.user(session['token']),42)
        self.assertEqual(self.request('/api/profile',token=session['token'],headers=headers)[0],200)
        self.assertEqual(self.request('/api/session',{'init_data':signed()+'bad'},headers=headers)[0],401)
        self.assertEqual(self.request('/api/demo-session',{},headers=headers)[0],401)

    def test_NFR_03_NFR_12_assets_and_security_headers(self):
        for file in ('/','/app.js','/style.css'):
            self.assertEqual(self.request(file)[0],200)
        with urllib.request.urlopen(self.base+'/') as response:
            self.assertIn("script-src 'self'",response.headers['Content-Security-Policy'])
        self.assertEqual(self.request('/../../README.md')[0],404)

class BotAcceptance(unittest.TestCase):
    def setUp(self):
        self.app=Application(':memory:',demo=True)
        self.worker=TelegramWorker(self.app); self.sent=[]
        self.worker.api=lambda method,data:self.sent.append((method,data)) or {'ok':True}
        self.app.storage.set_zone(42,'Europe/Moscow')
    def tearDown(self): self.worker.pool.shutdown(); self.app.storage.close()
    def message(self,text='',voice=None,update_id=1):
        msg={'from':{'id':42},'chat':{'id':42,'type':'private'},'text':text}
        if voice: msg['voice']=voice
        self.worker.handle({'update_id':update_id,'message':msg})
    def test_FR_01_start_text_voice_Mini_App_help(self):
        self.app.public_url='https://example.com'; self.message('/start')
        self.assertIn('текст',self.sent[0][1]['text']); self.assertIn('голос',self.sent[0][1]['text'])
        self.assertIn('web_app',json.dumps(self.sent[0][1]))
    def test_FR_02_FR_07_text_edit_and_confirm(self):
        self.message('Потратил 550 на такси')
        d=self.app.storage.pending(42)[0]
        self.app.storage.set_state(42,{'batch':d['id'],'index':0,'revision':0})
        self.message('amount=500',update_id=2)
        self.assertEqual(self.app.storage.draft(42,d['id'])['records'][0]['amount'],500)
    def test_FR_03_real_voice_adapter_mocked_file_not_fake_parser(self):
        self.worker.transcriber.transcribe=lambda path:'Завтра в 15:00 встреча'
        self.worker.api=lambda method,data:{'file_path':'voice.oga'} if method=='getFile' else self.sent.append((method,data)) or {}
        class Audio:
            def __enter__(self): return self
            def __exit__(self,*args): pass
            def read(self,*args): return b'test audio'
        with patch('urllib.request.urlopen',return_value=Audio()): self.message(voice={'file_id':'x','duration':10})
        self.assertEqual(self.app.storage.pending(42)[0]['records'][0]['type'],'event')
    def test_FR_26_transcriber_error_is_user_visible(self):
        self.worker.api=lambda method,data: {'file_path':'voice.oga'} if method=='getFile' else self.sent.append((method,data)) or {}
        self.worker.transcriber.transcribe=lambda path:(_ for _ in ()).throw(RuntimeError('secret'))
        class Audio:
            def __enter__(self): return self
            def __exit__(self,*a): pass
            def read(self,*a): return b'audio'
        with patch('urllib.request.urlopen',return_value=Audio()): self.message(voice={'file_id':'x'})
        self.assertIn('Не удалось распознать',self.sent[-1][1]['text'])
        self.assertNotIn('secret',self.sent[-1][1]['text'])

    def test_FR_14_worker_sends_notification_once(self):
        d=self.app.service.propose(42,'Завтра в 15:00 встреча, напомни за час')
        self.app.storage.confirm(42,d['id'],0)
        self.worker.send_due_reminders(utcnow()+timedelta(days=2))
        self.worker.send_due_reminders(utcnow()+timedelta(days=3))
        notifications=[p for method,p in self.sent if method=='sendMessage' and p['text'].startswith('Напоминание:')]
        self.assertEqual(len(notifications),1)

    def test_FR_14_worker_retries_after_transport_failure(self):
        d=self.app.service.propose(42,'Завтра в 15:00 встреча, напомни за час')
        self.app.storage.confirm(42,d['id'],0)
        saved=self.worker.api
        self.worker.api=lambda *a:(_ for _ in ()).throw(RuntimeError('offline'))
        self.worker.send_due_reminders(utcnow()+timedelta(days=2))
        self.worker.api=saved
        self.worker.send_due_reminders(utcnow()+timedelta(days=3))
        self.assertEqual(self.app.storage._conn.execute('SELECT status FROM reminders').fetchone()[0],'sent')

if __name__=='__main__': unittest.main()
