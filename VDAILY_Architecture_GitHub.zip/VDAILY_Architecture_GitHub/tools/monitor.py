"""NFR-04: run every 5 minutes for a calendar month; does not invent uptime."""
import argparse,csv,time,urllib.request
from datetime import datetime,timezone
from pathlib import Path

p=argparse.ArgumentParser(); p.add_argument('url'); p.add_argument('--interval',type=int,default=300); p.add_argument('--output',default='monitor.csv'); p.add_argument('--once',action='store_true'); a=p.parse_args()
path=Path(a.output)
try:
    while True:
        start=time.perf_counter(); success=0
        try:
            with urllib.request.urlopen(a.url.rstrip('/')+'/health',timeout=10) as response: success=int(response.status==200)
        except Exception: pass
        new=not path.exists()
        with path.open('a',newline='',encoding='utf-8') as file:
            writer=csv.writer(file)
            if new: writer.writerow(['utc','success','latency_seconds'])
            writer.writerow([datetime.now(timezone.utc).isoformat(),success,round(time.perf_counter()-start,4)])
        if a.once: break
        time.sleep(a.interval)
except KeyboardInterrupt: pass
