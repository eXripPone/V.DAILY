"""Run the full test suite and produce a portable factual test report."""
import io,json,sys,unittest
from pathlib import Path

root=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(root))
suite=unittest.defaultTestLoader.discover(str(root/'tests'))
stream=io.StringIO(); result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
out=root/'verification'; out.mkdir(exist_ok=True)
(out/'unittest.txt').write_text(stream.getvalue(),encoding='utf-8')
(out/'result.json').write_text(json.dumps({'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'success':result.wasSuccessful(),'external_services':'not executed: keys and pilot data required'},indent=2),encoding='utf-8')
print(stream.getvalue())
raise SystemExit(0 if result.wasSuccessful() else 1)
